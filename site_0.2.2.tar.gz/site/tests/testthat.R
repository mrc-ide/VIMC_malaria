library(testthat)
library(site)

test_check("site")
